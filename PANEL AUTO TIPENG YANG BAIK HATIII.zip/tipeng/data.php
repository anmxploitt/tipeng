<?php 
$nik = "JASTEB TIPENG 🇮🇩";
$sender = "support@tipeng.jasteb";
?>