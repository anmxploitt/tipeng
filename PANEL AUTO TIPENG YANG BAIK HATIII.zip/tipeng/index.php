<div id="postLocker" oncontextmenu="return false">
  <div class="lockerContainer" id="postLock">
    <div class="lockerTitle">PANEL JASTEB</div>
    <div class="lockerDescription">KAMU ITU LOH MANIS</div>
    <input id="lockerPassword" type="text" placeholder="MASUK IN PW LOL." onkeydown="if(event.keyCode==13)postLock()"/>
    <div class="lockerButton" onclick="postLock()"><i class="mainIcon lockIcon"></i>LOGIN</div>
    <div class="lockerOut">
      <a href="https://wa.me/6282134897549" title="Homepage">BELI PANEL JASTEB</a>
    </div>
  </div>
</div>
<div id="lockerContent" class="contentHide"/>


<style>
#postLocker{position:fixed;width:100%;height:100%;background:rgba(0,0,0,.01);font-family:"Noto Sans",sans-serif;top:0;left:0;right:0;bottom:0;backdrop-filter:blur(8px);z-index:999}
.lockerContainer{position:relative;width:35%;background:#fff;top:50%;left:50%;padding:30px;transform:translate(-50%,-50%);border-radius:15px;box-shadow:0 0 30px 0 rgba(0,0,0,.15)}
#lockerPassword{width:100%;background:#fff;color:#333;margin-bottom:7px;padding:10px;box-shadow:0 0 8px 0 rgba(0,0,0,.1)}
#lockerPassword::placeholder{color:#bbb;font-size:14px}
.lockerTitle{color:rgba(0,0,0,.5);font-size:45px;font-weight:bold;margin-top:10px;margin-left:-3.5px}
.lockerDescription{color:#333;font-size:14px;margin:15px 0}
.lockerOut a{color:#666;font-size:12px}
.lockerOut a:hover{color:#666}
.contentHide{display:none}
.lockerButton{display:inline-flex;background:#009ee0;color:#fff;font-size:13px;line-height:22px;align-items:center;margin:15px 0 10px 0;padding:10px 20px 10px 15px;outline:0;border:0;border-radius:0 30px 30px 30px;cursor:pointer}
.lockerButton:hover{background:#068ac2}
.mainIcon{display:inline-block;width:18px;height:18px;margin-right:12px;background-size:cover;background-repeat:no-repeat;background-position:center center}
.mainIcon.lockIcon{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-linecap='round' stroke-linejoin='round' stroke-width='2'><g transform='translate(3.500000, 2.000000)'><path d='M12.9709,7.4033 L12.9709,5.2543 C12.9399,2.7353 10.8719,0.7193 8.3539,0.7503 C5.8869,0.7813 3.8919,2.7673 3.8499,5.2343 L3.8499,7.4033'></path><line x1='8.4103' y1='12.1562' x2='8.4103' y2='14.3772'></line><path d='M8.4103,6.8242 C2.6653,6.8242 0.7503,8.3922 0.7503,13.0952 C0.7503,17.7992 2.6653,19.3672 8.4103,19.3672 C14.1553,19.3672 16.0713,17.7992 16.0713,13.0952 C16.0713,8.3922 14.1553,6.8242 8.4103,6.8242 Z'></path></g></svg>")}
@media screen and (max-width:700px){.lockerContainer{width:95%;border-radius:3px}}
</style>


<script>
function postLock(){if(document.getElementById("lockerPassword").value==="sewake729"){document.getElementById("lockerContent").classList.remove("contentHide");document.getElementById("postLocker").classList.add("contentHide")}else{alert("Kamu Siapa? beli : 082134897549");lockerPassword.setSelectionRange(0,lockerPassword.value.length)}return false}
</script>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
    PANEL JASTEB BY TIPENG NESIA
    </title>
    <meta charset="UTF-8">
    <meta name="Description" content="domain Gratisan Ini kalo merah/kaga bisa jan bacot kntl modal makanya kalo mau enak">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="https://cdn3.vectorstock.com/i/1000x1000/45/22/ng-logo-monogram-emblem-style-with-crown-shape-vector-31864522.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <script src='https://unpkg.com/splitting/dist/splitting.min.js'></script>
    <link rel='stylesheet' href='https://unpkg.com/splitting/dist/splitting.css'>
    <link rel='stylesheet' href='https://unpkg.com/splitting/dist/splitting-cells.css'>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7579749581890015"
     crossorigin="anonymous"></script>
  </head>
<style>
@import url("https://fonts.googleapis.com/css2?family=Bungee&family=Viga&display=swap");
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  user-select: none;
}
body {
  position: relative;
  width: 100%;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: url("https://source.unsplash.com/random/?game,technology")
    no-repeat center;
  background-attachment: fixed;
  background-size: cover;
}
body:after {
  content: "";
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.9);
  backdrop-filter: blur(1px);
  z-index: -1;
}
.app {
    position: relative;
    width: 100%;
    min-height: 100vh;
    display: flex; 
    align-items: center;
    justify-content: center;
    flex-direction: column;
    padding: 20px;
    padding-top: 60px;
    padding-bottom: 40px;
}
.app .nav {
    position: fixed;
    z-index:99999999;
    top:0;
    left: 50%;
    transform: translateX(-50%);
    width: 100%;
    height: 40px;
    font-family: 'Viga', sans-serif;
    backdrop-filter: blur(16px) saturate(180%);
    -webkit-backdrop-filter: blur(16px) saturate(180%);
    background-color: rgba(0, 0, 0, 0.75);
    box-shadow: 0 1px 5px rgba(17, 25, 40, 0.75),
        0 1px 10px rgba(17, 25, 40, 0.75);
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 10px;
}
.nav .logo {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    left: -5px;
    width: 50px;
    height: 35px;
    object-fit: cover;
    border-radius: 50%;
}
.nav .fill {
    position: relative;
    padding: 5px;
    margin: 0 5px;
    color: #fff;
    font-family: 'Viga', sans-serif;
}
.nav .fill i {
    color: #fff;
    cursor: pointer;
}
.app .copy {
  width: 100%;
  position: fixed;
  bottom: 2px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.6);
  font-size: 13px;
  backdrop-filter: blur(16px) saturate(180%);
  -webkit-backdrop-filter: blur(16px) saturate(180%);
  background-color: rgba(0, 0, 0, 0.75);
  box-shadow: 0 1px 5px rgba(17, 25, 40, 0.75),
        0 1px 10px rgba(17, 25, 40, 0.75);
  padding: 5px;
}
.app .labels {
  position: relative;
  width: 400px;
  text-align: left;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.7);
  font-size: 19px;
  margin-top: 20px;
  padding-left: 10px;
}
.app .labels:before {
  content: "";
  position: absolute;
  top: 50%;
  left: 0;
  transform: translateY(-60%);
  width: 3px;
  height: 15px;
  background: #fff;
  /* border-radius: 50%; */
  z-index: 99;
}
.app .labels:after {
  content: "";
  position: absolute;
  top: 50%;
  left: 3px;
  transform: translateY(-100%);
  width: 3px;
  height: 3px;
  background: #fff;
  border-radius: 50%;
  z-index: 99;
}
.app .bungkus {
  position: relative;
  padding: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  backdrop-filter: blur(2px) saturate(200%);
  -webkit-backdrop-filter: blur(2px) saturate(200%);
  background-color: rgba(45, 34, 68, 0.5);
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.125);
  margin-top: 5px;
}

.app h1 {
    font-family: 'Viga', sans-serif;
    color: rgba( 255, 255, 255, 0.4 );
    line-height: 25px;
}
h1 strong {
    font-family: 'Bungee', cursive;
    font-size: 2em;
}
.app .desc {
    margin-top: 10px;
    font-family: 'Viga', sans-serif;
    color: rgba( 255, 255, 255, 0.4 );
    text-align: center;
}

.bungkus h1 {
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.7);
  line-height: 28px;
}
.bungkus label {
  width: 400px;
  text-align: left;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.7);
  margin-top: 15px;
  font-size: 15px;
}
.bungkus label:first-child {
  margin-top: 0;
}
.app .check {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 16px;
  padding: 5px 20px;
  margin-top: 20px;
  cursor: pointer;
}
.bungkus .check:focus {
  outline: none;
  border: none;
}
.bungkus .inner {
  position: relative;
  width: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.inner h1 {
    font-size: 18px;
}
.inner.mt-5 {
  margin-top: 5px;
}
.inner .input {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  width: 400px;
  height: 40px;
  font-size: 15px;
  padding: 0 5px;
}
.bungkus .action {
  margin-top: 5px;
  position: relative;
  width: 100%;
  display: none;
  align-items: center;
  justify-content: flex-start;
}
.bungkus .action.show {
  display: flex;
}
.action .ip {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  height: 23px;
  font-size: 14px;
  width: 120px;
  text-align: center;
  padding: 5px;
  margin-right: 10px;
}
.action .ip:focus {
  outline: none;
  border: none;
}
.action .send {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 12px;
  padding: 0 5px;
  height: 23px;
  margin: 0 3px;
  cursor: pointer;
}
.action .send:focus {
  outline: none;
  border: none;
}
.send.green {
  background: rgba(124, 252, 0, 0.4);
}
.send.red {
  background: rgba(255, 0, 0, 0.4);
}
.inner .domains {
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
  z-index: 9999;
  background: #000;
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(0, 0, 0, 0.4);
  color: rgba(255, 255, 255, 0.4);
  font-family: "Viga", sans-serif;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  padding: 0 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
.domains select {
  position: relative;
  width: 100%;
  height: 100%;
  outline: none;
  border: none;
  background: none;
  cursor: pointer;
  color: rgba(255, 255, 255, 0.4);;
  font-family: "Viga", sans-serif;
}
.inner .input:focus {
  outline: none;
  border: none;
}
.app .input::placeholder {
  color: rgba(255, 255, 255, 0.4);
}
.app .alert {
  position: relative;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 14px;
  padding: 3px 15px 3px 25px;
  text-align: center;
  display: none;
}
.alert.success {
  background: rgba(124, 252, 0, 0.4);
}
.alert.error,
.alert.failed,
.alert.exsist,
.alert.mistake {
  background: rgba(255, 0, 0, 0.4);
}
.alert.process {
  background: rgba(0, 0, 255, 0.4);
}
.alert i {
  position: absolute;
  top: 50%;
  left: 5px;
  transform: translateY(-60%);
}
.alert.process i {
  top: 25%;
}
.app .conz {
  position: relative;
  width: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}
.app .details {
  position: relative;
  margin-top: 20px;
  font-family: "Viga", sans-serif;
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  padding: 10px;
  width: 400px;
  text-align: center;
  display: none;
}
.details h1 {
  font-size: 20px;
}
.details .active {
  margin-top: 10px;
  position: relative;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: column;
}
.active .info {
  position: relative;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.1);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 13px;
  padding: 5px 15px;
}
.details table {
  margin-top: 10px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);
  border-top: 1px solid rgba(255, 255, 255, 0.3);
}
.active .click {
  position: relative;
  margin-top: 10px;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 14px;
  padding: 5px 15px;
}
.active .click:focus {
  outline: none;
  border: none;
}
.app .btn {
  position: absolute;
  top: 10px;
  right: 10px;
  font-family: "Viga", sans-serif;
  background: rgba(255, 255, 255, 0.4);
  color: rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  font-size: 16px;
  padding: 5px 20px;
}
.app .btn:focus {
  outline: none;
  border: none;
}

.rainbow-text .char { 
  
  color: hsl(
    calc(360deg * var(--char-percent)
    ), 
    90%, 
    65%
  );
 
}

.rainbow-text.animated .char {
  animation: rainbow-colors 2s linear infinite;
  animation-delay: calc(-2s * var(--char-percent));
}
/* Unfortunately, browsers try to take the shortest distance between transition/animation properties, so a simple `0turn` to `1turn` doesn't get the proper effect. */
@keyframes rainbow-colors {
  0% { color: hsl(197, 97%, 66%, 1); }
  25% { color: hsl(0, 100%, 100%, 1); }
  50% { color: hsl(348, 83%, 81%, 1); }
  75% { color: hsl(.75turn, 90%, 65%); }
  100% { color: hsl(1turn, 90%, 65%); }
}

@media (max-width: 550px) {
  .app .inner,
  .inner .input,
  .app .details,
  .bungkus label,
  .app .bungkus,
  .app .labels, 
  .app .conz {
    width: 100%;
  }
}
</style>
  <body>
    <div class="app">
      
    <div class="nav">
        <img class="logo" src="https://cdn3.vectorstock.com/i/1000x1000/45/22/ng-logo-monogram-emblem-style-with-crown-shape-vector-31864522.jpg">
        <div class="fill" onclick="window.location.href='https://wa.me/6282136031499;">WhastsApp</div>
        <div class="fill" onclick="window.location.href='/;">Website</div>
    </div>


    <h1>TIPENG<strong>NESIA</strong>PANEL</h1>
    <p class="desc">Panel by Tipeng Ya Kontol</p>


        <div class="check" onclick="window.location='sewaake7wsi2osj2iieido002893yhs.php';">Mulai Mek</div>


     
    <span class="copy">
    PANEL JASTEB BY TIPENG NESIA
    <div class="rainbow-text" data-splitting></div>
    <div class="rainbow-text animated" data-splitting style="margin-left:5px;">Website : https://linktr.ee/tipengnesia </div>
    </span>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        Splitting();
    </script>
  </body>
</html>